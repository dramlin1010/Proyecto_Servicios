<?php
$servername = "localhost:3311";
$username = "root";
$password = "";
$dbname = "Hosting";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>