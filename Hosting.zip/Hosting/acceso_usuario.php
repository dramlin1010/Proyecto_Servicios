<?php
session_start(); // Iniciar sesión para almacenar información del usuario

$servidor = "localhost:3311";
$usuario = "root";
$password = "";
$DB = "Hosting";
$conexion_DB = new mysqli($servidor, $usuario, $password, $DB);

if ($conexion_DB->connect_error) {
    die("Error de conexión: " . $conexion_DB->connect_error);
}

$email = $_POST["Email"];
$passwd = $_POST["Passwd"];

$sql = "SELECT * FROM Cliente WHERE Email = ?";
$stmt = $conexion_DB->prepare($sql);
$stmt->bind_param("s", $email); // 's' indica que el parametro es una cadena
$stmt->execute();
$resultado = $stmt->get_result();

/*Vulnerable a INYECCION SQL
$sql = "SELECT * FROM Cliente WHERE Email = '$email'";
$resultado = $conexion_DB->query($sql);
*/

// Verificar si se encuentra el usuario
if ($resultado->num_rows > 0) {
    // El usuario existe, obtener los datos
    $usuario = $resultado->fetch_assoc();

    // Verificar si la contraseña es correcta
    if (password_verify($passwd, $usuario['Passwd'])) {
        // Iniciar sesion para el usuario
        $_SESSION['ClienteID'] = $usuario['ClienteID'];
        $_SESSION['Nombre'] = $usuario['Nombre'];
        $_SESSION['Email'] = $usuario['Email'];

        $token = bin2hex(random_bytes(32));
        $_SESSION['token'] = $token;  // Guardar en sesion
        setcookie("session_token", $token, time() + 3600, "/", "", true, true);  // Cookie segura

        // Verificar si es el administrador
        if ($email === "admin@hosting.com") {
            // Configurar una cookie segura para el administrador (expira en 1 hora)
            setcookie("admin_session", session_id(), time() + 3600, "/", "", true, true);
            header("Location: admin/panel.php");
        } else {
            header("Location: panel_usuario.php");
        }
        exit();
    } else {
        echo "Correo electronico o Contraseña Incorrecta.";
    }
} else {
    echo "Correo electronico o Contraseña Incorrecta.";
}

$stmt->close();
$conexion_DB->close();
?>
