<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['ClienteID'])) {
    header("Location: login.php");
    exit();
}

require 'conexion.php';

$ClienteID = $_SESSION['ClienteID'];
$facturaID = $_POST['factura_id']; // Obtener el ID de la factura desde el formulario

// Buscar la factura para asegurarse de que es válida y está pendiente
$sql = "SELECT * FROM Factura WHERE FacturaID = $facturaID AND ClienteID = $ClienteID AND Estado = 'pendiente'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    // Si encontramos una factura pendiente, procedemos a marcarla como pagada
    $sql_update = "UPDATE Factura SET Estado = 'pagado' WHERE FacturaID = $facturaID AND ClienteID = $ClienteID";
    if ($conn->query($sql_update) === TRUE) {
        // Redirigir al panel de usuario con un mensaje de éxito
        header("Location: panel_usuario.php");
    } else {
        echo "Error al actualizar el estado de la factura: " . $conn->error;
    }
} else {
    echo "Factura no encontrada o ya está pagada.";
}

$conn->close();
?>
